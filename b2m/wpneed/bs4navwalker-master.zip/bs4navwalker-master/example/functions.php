<?php

require_once('bs4navwalker.php');

register_nav_menu('top', 'Top menu');

